/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <vector>

int main() {
    std::vector<int> distancias = {50, 55, 57, 58, 60};
    int t = 174;

    int n = distancias.size();
    int maxSum = 0;
    std::vector<int> seleccionadas;

    for (int i = 0; i < n - 2; i++) {
        for (int j = i + 1; j < n - 1; j++) {
            for (int k = j + 1; k < n; k++) {
                int suma = distancias[i] + distancias[j] + distancias[k];
                if (suma <= t && suma > maxSum) {
                    maxSum = suma;
                    seleccionadas = {distancias[i], distancias[j], distancias[k]};
                }
            }
        }
    }

    std::cout << "Las distancias seleccionadas son: ";
    for (int i = 0; i < seleccionadas.size(); i++) {
        std::cout << seleccionadas[i];
        if (i < seleccionadas.size() - 1) {
            std::cout << ", ";
        }
    }
    std::cout << std::endl;

    std::cout << "La suma máxima de distancias es: " << maxSum << " millas" << std::endl;

    return 0;
}
