/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

int main() {
    int horas1, minutos1, segundos1;
    int horas2, minutos2, segundos2;
    
    // Ingresa los tiempos del primer atleta
    std::cout << "Ingresa el tiempo del primer atleta en horas, minutos y segundos:" << std::endl;
    std::cout << "Horas: ";
    std::cin >> horas1;
    std::cout << "Minutos: ";
    std::cin >> minutos1;
    std::cout << "Segundos: ";
    std::cin >> segundos1;

    // Ingresa los tiempos del segundo atleta
    std::cout << "Ingresa el tiempo del segundo atleta en horas, minutos y segundos:" << std::endl;
    std::cout << "Horas: ";
    std::cin >> horas2;
    std::cout << "Minutos: ";
    std::cin >> minutos2;
    std::cout << "Segundos: ";
    std::cin >> segundos2;

    // Suma los tiempos de ambos atletas
    int totalHoras = horas1 + horas2;
    int totalMinutos = minutos1 + minutos2;
    int totalSegundos = segundos1 + segundos2;

    // Manejar el acarreo de segundos a minutos y de minutos a horas si es necesario
    if (totalSegundos >= 60) {
        totalMinutos += totalSegundos / 60;
        totalSegundos %= 60;
    }
    if (totalMinutos >= 60) {
        totalHoras += totalMinutos / 60;
        totalMinutos %= 60;
    }

    // Imprimir el resultado
    std::cout << "El tiempo total utilizado por ambos atletas es: " << std::endl;
    std::cout << "Horas: " << totalHoras << std::endl;
    std::cout << "Minutos: " << totalMinutos << std::endl;
    std::cout << "Segundos: " << totalSegundos << std::endl;

    return 0;
}
