/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

int main() {
    double cantidadPies, cantidadMetros;
    
    std::cout << "Ingresa la cantidad en pies: ";
    std::cin >> cantidadPies;
    std::cout << "Ingresa la cantidad en metros: ";
    std::cin >> cantidadMetros;

    double sumaPulgadas = cantidadPies * 12 + cantidadMetros / 0.0254;
    double sumaYardas = (cantidadPies / 3) + cantidadMetros / 0.9144;
    double sumaMetros = cantidadPies * 0.3048 + cantidadMetros;
    double sumaMillas = cantidadMetros / 1609.0;

    std::cout << "La suma en pulgadas es: " << sumaPulgadas << std::endl;
    std::cout << "La suma en yardas es: " << sumaYardas << std::endl;
    std::cout << "La suma en metros es: " << sumaMetros << std::endl;
    std::cout << "La suma en millas es: " << sumaMillas << std::endl;

    return 0;
}
