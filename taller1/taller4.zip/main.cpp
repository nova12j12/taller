/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

int main() {
    double num1, num2;
    char operacion;

    std::cout << "Ingrese el primer número: ";
    std::cin >> num1;
    std::cout << "Ingrese el segundo número: ";
    std::cin >> num2;

    std::cout << "Elija una operación: " << std::endl;
    std::cout << "a. Suma (+)" << std::endl;
    std::cout << "b. Resta (-)" << std::endl;
    std::cout << "c. Multiplicación (*)" << std::endl;
    std::cout << "d. División (/)" << std::endl;
    std::cout << "Ingrese la letra correspondiente a la operación: ";
    std::cin >> operacion;

    switch (operacion) {
        case 'a':
        case 'A':
            std::cout << "La suma es: " << num1 + num2 << std::endl;
            break;
        case 'b':
        case 'B':
            std::cout << "La resta es: " << num1 - num2 << std::endl;
            break;
        case 'c':
        case 'C':
            std::cout << "La multiplicación es: " << num1 * num2 << std::endl;
            break;
        case 'd':
        case 'D':
            if (num2 != 0) {
                std::cout << "La división es: " << num1 / num2 << std::endl;
            } else {
                std::cout << "Error: No se puede dividir por cero." << std::endl;
            }
            break;
        default:
            std::cout << "Operación no válida." << std::endl;
            break;
    }

    return 0;
}
