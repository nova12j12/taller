/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

int main() {
    int numHijos, edadHijos;
    bool madreViuda;

    std::cout << "Ingrese el número de hijos en la familia: ";
    std::cin >> numHijos;

    std::cout << "Ingrese la edad de los hijos en edad escolar (entre 6 y 18 años): ";
    std::cin >> edadHijos;

    std::cout << "¿La madre de familia es viuda? (1 para sí, 0 para no): ";
    std::cin >> madreViuda;

    double montoMensual = 0.0;

    if (numHijos <= 2) {
        montoMensual += 70.0;
    } else if (numHijos <= 5) {
        montoMensual += 90.0;
    } else {
        montoMensual += 120.0;
    }

    if (edadHijos >= 6 && edadHijos <= 18) {
        montoMensual += 10.0 * (numHijos - 2);
    }

    if (madreViuda) {
        montoMensual += 20.0;
    }

    std::cout << "El monto mensual que recibirá la familia es: S/." << montoMensual << std::endl;

    return 0;
}
